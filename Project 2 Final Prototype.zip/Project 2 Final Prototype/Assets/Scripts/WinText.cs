using UnityEngine;
using UnityEngine.SceneManagement;

public class WinText : MonoBehaviour
{

    public static WinText instance;
    [SerializeField] private GameObject winMessage;
    private bool hasWon;

    void Awake()
    {
        instance = this;
    }

    void Update()
    {
        if (hasWon && Input.anyKeyDown)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    public void Win()
    {
        if (winMessage == null)
        {
            Debug.LogError("Win message is not assigned.", this);
            return;
        }

        winMessage.SetActive(true);
        hasWon = true;
    }
}
