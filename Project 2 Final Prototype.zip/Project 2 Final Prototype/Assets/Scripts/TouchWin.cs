using UnityEngine;

public class TouchWin : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Debug.Log("touched win plate");
            WinText.instance.Win(); 
        }
    }
}
