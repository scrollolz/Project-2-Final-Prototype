using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class CupMechanics : MonoBehaviour
{
    public NavMeshAgent snail;
    private GameObject cup;
    [SerializeField] private GameObject blueObjective;
    [SerializeField] private GameObject greenObjective;
    [SerializeField] private GameObject pinkObjective;
    private float originalSpeed;
    private bool isUsingCup;

    public bool IsUsingCup => isUsingCup;

    private void Start()
    {
        if (snail == null)
            snail = GetComponent<NavMeshAgent>();
        if (snail == null)
            snail = GetComponentInParent<NavMeshAgent>();
        if (snail == null)
            snail = GetComponentInChildren<NavMeshAgent>();

        if (snail == null)
        {
            Debug.LogError("CupMechanics requires a NavMeshAgent on the snail.", this);
            enabled = false;
            return;
        }

        Transform cupTransform = snail.transform.Find("Cup");
        if (cupTransform == null)
        {
            Debug.LogError("Couldn't find a child named Cup on the snail.", this);
            enabled = false;
            return;
        }

        cup = cupTransform.gameObject;
        cup.SetActive(false);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E) && !isUsingCup && GameControl.instance != null && GameControl.instance.Score > 0)
            StartCoroutine(UseCup());
    }

    private IEnumerator UseCup()
    {
        if (GameControl.instance == null || GameControl.instance.Score < 1)
            yield break;

        isUsingCup = true;
        RestoreInactiveObjective();
        originalSpeed = snail.speed;
        snail.speed = 0f;
        cup.SetActive(true);
        GameControl.instance.DecreaseScore();

        yield return new WaitForSeconds(5f);

        cup.SetActive(false);
        snail.speed = originalSpeed;
        isUsingCup = false;
    }

    private void RestoreInactiveObjective()
    {
        GameObject[] objectives = { blueObjective, greenObjective, pinkObjective };
        foreach (GameObject objective in objectives)
        {
            if (objective == null)
            {
                Debug.LogError("Assign all three objective objects in the CupMechanics Inspector.", this);
                return;
            }

            if (!objective.activeSelf)
            {
                objective.SetActive(true);
                Debug.Log(objective.name + " placed back");
                return;
            }
        }

        Debug.Log("All objectives are already active.", this);
    }
}
