using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class GameControl : MonoBehaviour
{

    private int score = 0;
    public static GameControl instance;
    public TMP_Text scoreText;

    public int Score { get { return score; } }

    void Awake()
    {
        instance = this;
    }
    void Update()
    {
        if (score == 3)
        {
            Debug.Log("Door is open");
            DoorBehavior.instance.OpenDoor();
            score++;
        }
        if (gameOver == true)
        {
            Restart(5);
        }
    }
    public bool gameOver = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void Scored()
    {
        if (gameOver)
        {
            return;
        }

        score++;
        scoreText.text = "Objects collected: " + score.ToString();
        Debug.Log("Score: " + score);

    }

    public void DecreaseScore()
    {
        score--;
        scoreText.text = "Objects collected: " + score.ToString();
        Debug.Log("Score: " + score);
    }

    public void GameOver()
    {
        gameOver = true;
        Debug.Log("Game Over");
    }

    IEnumerator Restart(float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
