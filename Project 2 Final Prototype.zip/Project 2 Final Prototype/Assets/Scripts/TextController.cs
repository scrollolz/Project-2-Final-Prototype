using UnityEngine;

public class TextController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
        Time.timeScale = 0;
    }

void Update () 
{
	if(Input.anyKeyDown)
	{
		Time.timeScale = 1;
		Destroy(gameObject);
	}
}
}
